from assets import AssetManager;
from sprites import SpriteBank;

def get_sprite(entity):
	prototype = AssetManager.get_document("prototype").search(entity["prototype"]);
	if prototype == None:
		return None;
	return SpriteBank.search(prototype["sprite"], safe=False);

def get_aabb(entity):
	x, y = entity["position"];

	prototype = AssetManager.get_document("prototype").search(entity["prototype"]);
	if prototype != None:
		sprite = SpriteBank.search(prototype["sprite"], safe=False);
		if sprite != None:
			dx, dy = prototype["sprite_offset"];
			return [x+dx, y+dy, x+dx+sprite.width, y+dy+sprite.height];
	
		for blocker in prototype["blockers"]:
			if blocker["type"] == "aabb":
				x0, y0, x1, y1 = blocker["aabb"];
				return [x+x0, y+y0, x+x1, y+y1];
		if prototype["has_trigger"]:
			x0, y0, x1, y1 = prototype["trigger"];
			return [x+x0, y+y0, x+x1, y+y1];

	return [x-8, y-8, x+8, y+8];

def get_body_key(entity):
	return (0, 0, get_depth(entity));

def get_depth(entity):
	prototype = AssetManager.get_document("prototype").search(entity["prototype"]);
	y_offset = prototype["y_sort_offset"] if prototype != None else 0;
	return get_aabb(entity)[3] + y_offset;

def spawn(scene, prototype_name, position):
	entity = AssetManager.get_document("scene").type_tree.search("entities").inmost.prototype();
	entity["name"] = "";
	entity["position"] = [int(position[0]), int(position[1])];
	entity["prototype"] = prototype_name;
	scene["entities"].append(entity);
	return entity;
