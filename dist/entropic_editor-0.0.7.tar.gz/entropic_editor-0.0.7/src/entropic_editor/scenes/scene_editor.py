from imgui_bundle import imgui;
import glfw;
import csv;
import copy;

from cowtools import *;
from canvas import *;
from assets import *;
from sprites import SpriteBank;
from input import InputManager;
from editor_gui import *;
from geometry import *;
import scenes.walls;
import scenes.tilemaps;
import scripts;

#########################################################
## HELPERS

def get_entity_sprite(entity):
	prototype = AssetManager.search("prototype", entity["prototype"]);
	if prototype == None:
		return None;
	return SpriteBank.search(prototype["sprite"], safe=False);

def get_entity_aabb(entity):
	x, y = entity["position"];

	prototype = AssetManager.search("prototype", entity["prototype"]);
	if prototype != None:
		sprite = SpriteBank.search(prototype["sprite"], safe=False);
		if sprite != None:
			dx, dy = prototype["sprite_offset"];
			return [x+dx, y+dy, x+dx+sprite.frame_width, y+dy+sprite.frame_height];
	
		if prototype["has_blocker"]:
			x0, y0, x1, y1 = prototype["blocker"];
			return [x+x0, y+y0, x+x1, y+y1];
		elif prototype["has_trigger"]:
			x0, y0, x1, y1 = prototype["trigger"];
			return [x+x0, y+y0, x+x1, y+y1];

	return [x-8, y-8, x+8, y+8];

def get_text_aabb(text):
	x0, y0 = text["position"];
	width = len(text["text"]) * 8 * text["scale"];
	x1, y1 = x0 + width, y0 + 8 * text["scale"];
	return [x0, y0, x1, y1];

def get_script_data(entity, key):
	return next((x for x in entity["script_data"] if x["signature"]["key"] == key), None);
	
#########################################################
## SCENE EDITOR

class EditMode(Enum):
	ENTITIES = 0,
	TILEMAP = 1,
	WALLS = 2,
	DOORS = 3,
	NAVLISTS = 4,
	TEXTS = 5,
	PROPERTIES = 6

class TilemapEditor:
	def __init__(self, parent):
		self.parent = parent;
		self.tilemaps = None;
		self.tilemap = None;
		
		self.selected_frame = 0;
		self.cursor = None;

	def on_load_scene(self):
		self.tilemaps = self.parent.scene["tilemaps"];
		self.tilemap = self.tilemaps[0] if len(self.tilemaps) > 0 else None;
	
	def draw_palette(self):
		self.tilemap["palette"] = input_asset("Palette", self.tilemap["palette"], "sprite");

		sprite = SpriteBank.search(self.tilemap["palette"]);
		if sprite == None:
			return;
	
		wdw_w = imgui.get_content_region_avail().x;
		cols = int(wdw_w // 72);
		rows = int(math.ceil(sprite.frame_count / cols)) if cols > 0 else 0;

		i = 0;
		for r in range(rows):
			for c in range(cols):
				if i < sprite.frame_count:
					tint = (0.5, 0.5, 0.5, 1) if i == self.selected_frame else (1, 1, 1, 1);
					if imgui.image_button(f"##{i}", imgui.ImTextureRef(sprite.frame_textures[i]), (64, 64), tint_col=tint):
						self.selected_frame = i;
					imgui.same_line();
				i += 1;
			imgui.new_line();
	
	def draw_gui(self):
		self.tilemap = combo("Tilemap", self.tilemap, self.tilemaps, lambda x: self.tilemaps.index(x) if x != None else None);
		if self.tilemap == None:
			return;

		type_last = self.tilemap["type"];
		self.tilemap["type"] = input_enum("Type", self.tilemap["type"], ["sparse", "dense"]);
		if type_last == "sparse" and self.tilemap["type"] == "dense":
			self.tilemap["dense"] = scenes.tilemaps.sparse_to_dense(self.tilemap["sparse"]);
		if type_last == "dense" and self.tilemap["type"] == "sparse":
			self.tilemap["sparse"] = scenes.tilemaps.dense_to_sparse(self.tilemap["dense"]);
		
		if self.tilemap["type"] == "dense":
			self.tilemap["dense"]["position"] = input_vec2("Position", self.tilemap["dense"]["position"]);
			self.tilemap["dense"]["rows"] = input_int("Rows", self.tilemap["dense"]["rows"]);
			self.tilemap["dense"]["columns"] = input_int("Columns", self.tilemap["dense"]["columns"]);
			enforce_length(self.tilemap["dense"]["frame_indices"], self.tilemap["dense"]["rows"] * self.tilemap["dense"]["columns"], 0);
		
		self.tilemap["is_foreground"] = input_bool("Is Foreground", self.tilemap["is_foreground"]);

		self.draw_palette();

		self.tilemap["csv"] = input_file("CSV", self.tilemap["csv"], "*.csv", "assets/scenes/tilemaps", return_absolute=True);
		if imgui.button("Import"):
			scenes.tilemaps.import_tilemap(self.tilemap, self.tilemap["csv"]);
		imgui.same_line();
		if imgui.button("Export"):
			scenes.tilemaps.export_tilemap(self.tilemap, self.tilemap["csv"]);
	
	def paint(self):
		if self.cursor == None:
			return;
	
		palette = SpriteBank.search(self.tilemap["palette"]);
		self.selected_frame = clamp(self.selected_frame, 0, palette.frame_count-1);
		x, y = self.cursor;

		if InputManager.is_held(glfw.MOUSE_BUTTON_LEFT):
			if InputManager.is_held(glfw.KEY_LEFT_SHIFT):
				scenes.tilemaps.clear_tile(self.tilemap, x, y);
			else:
				scenes.tilemaps.place_tile(self.tilemap, self.selected_frame, x, y);

	def tick(self):
		if self.tilemap == None:
			return;
		
		if self.parent.canvas_io.is_cursor_in_bounds():
			self.cursor = self.parent.canvas_io.get_cursor();
		else:
			self.cursor = None;
		
		self.paint();

class WallEditor:
	def __init__(self, parent):
		self.parent = parent;
		self.walls = None;

		self.event_queue = [];
		self.canvas_manip = CanvasManipulator(self.parent.canvas_io, self.event_queue);
		self.manip_registry = CanvasManipRegistry();
		self.selection_context = SelectionContext();
		self.trash = Trash(deferred=True);

		self.place_mode = "none";

	def on_load_scene(self):
		self.walls = self.parent.scene["walls"];
		self.canvas_manip.clear();
		self.manip_registry.clear();
		self.selection_context.clear();
		self.trash.clear();
	
	def draw_gui(self):
		if self.walls == None:
			return;

		self.place_mode = input_enum("Place mode", self.place_mode, ["none", "aabb", "segment"]);

		for idx, wall in enumerate(self.walls):
			imgui.set_next_item_open(self.selection_context.is_selected(wall));
			node_open = imgui.tree_node(f"Wall {idx}##{id(self.walls)}{idx}");

			if imgui.begin_popup_context_item():
				if imgui.menu_item_simple("Delete"):
					self.trash.trash_index(self.walls, idx);
					imgui.close_current_popup();
				imgui.end_popup();
			self.trash.flush();

			if node_open:
				scenes.walls.gui_draw(wall);
				imgui.tree_pop();

	def synchronize_manip(self):
		def make_shape(wall):
			match wall["type"]:
				case "aabb":
					return CanvasManipRect(wall["aabb"]);
				case "segment":
					return CanvasManipSegment(wall["segment"]);
		shapes = [make_shape(x) for x in self.walls];
		
		self.manip_registry.update(self.walls, shapes);
		self.canvas_manip.synchronize(self.manip_registry);
	
	def handle_events(self):
		while len(self.event_queue) > 0:
			event = self.event_queue.pop(0);

			if isinstance(event, CanvasManipClick):
				hit = event.eeid != None;
				if hit:
					self.selection_context.select(self.manip_registry.search(event.eeid), exclusive=True);
					continue;
				if InputManager.is_held(glfw.KEY_LEFT_SHIFT):
					continue;
				
				new_wall = scenes.walls.canvas_place(event.point, self.place_mode, self.parent.canvas_grid);
				if new_wall != None:
					self.walls.append(new_wall);
					self.selection_context.select(new_wall);

			if isinstance(event, CanvasManipDrag):
				if event.eeid == None:
					self.parent.view_drag_handler(event);
					continue;
				wall = self.manip_registry.search(event.eeid);
				scenes.walls.canvas_drag(wall, event, self.parent.canvas_grid);		
	
	def tick(self):
		if self.walls == None:
			return;
	
		if InputManager.is_held(glfw.KEY_LEFT_SUPER) and InputManager.is_pressed(glfw.KEY_D):
			selected = self.selection_context.get_selection(True);
			self.trash.trash_item(self.walls, selected);
			self.trash.flush();
			self.selection_context.clear();
		
		self.synchronize_manip();
		self.canvas_manip.tick();
		self.handle_events();

class TextEditor:
	def __init__(self, parent):
		self.parent = parent;
		self.texts = None;

		self.event_queue = [];
		self.canvas_manip = CanvasManipulator(self.parent.canvas_io, self.event_queue);
		self.manip_registry = CanvasManipRegistry();
		self.context = {};

	def on_load_scene(self):
		self.texts = self.parent.scene["texts"];
		self.canvas_manip.clear();
		self.manip_registry.clear();
		self.event_queue.clear();
		self.context.clear();
	
	def draw_gui(self):
		if self.texts == None:
			return;
	
		node_open = imgui.tree_node(f"Texts##{id(self.texts)}");

		if imgui.begin_popup_context_item():
			if imgui.menu_item_simple("New text"):
				self.texts.append({
					"text": "Hello, world!",
					"colour": [255, 255, 255],
					"scale": 1,
					"position": [0, 0]
				});
				imgui.close_current_popup();
			imgui.end_popup();

		if node_open:
			trash = [];

			for idx, text in enumerate(self.texts):
				node_open = imgui.tree_node(f"{idx}##{id(self.texts)}{idx}");

				if imgui.begin_popup_context_item():
					trash = [];
					if imgui.menu_item_simple("Delete"):
						trash.append(idx);
						imgui.close_current_popup();
					imgui.end_popup();

				if node_open:
					text["text"] = input_string("Text", text["text"]);
					text["colour"] = input_colour("Colour", text["colour"]);
					text["scale"] = input_int("Scale", text["scale"]);
					text["position"] = input_vec2("Position", text["position"]);
					imgui.tree_pop();
			
			process_trash(self.texts, trash, indices=True);
			imgui.tree_pop();
	
	def _synchronize_manip(self):
		indices = [i for i in range(len(self.texts))];

		def make_shape(idx):
			text = self.texts[idx];
			aabb = get_text_aabb(text);
			return CanvasManipRect(aabb);
		shapes = [make_shape(x) for x in indices];
		
		self.manip_registry.update(indices, shapes);
		self.canvas_manip.synchronize(self.manip_registry);
	
	def _move_text(self, text, point):
		x, y = point;
		text["position"][0] = int(x);
		text["position"][1] = int(y);
	
	def _handle_events(self):
		while len(self.event_queue) > 0:
			event = self.event_queue.pop(0);

			if isinstance(event, CanvasManipDrag):
				if event.eeid != None:
					match event.signal:
						case CanvasManipDrag.Signal.START:
							text = self.texts[self.manip_registry.search(event.eeid)];
							self.context = {
								"delta": (text["position"][0] - event.point[0], text["position"][1] - event.point[1]),
							}
						case CanvasManipDrag.Signal.TICK:
							text = self.texts[self.manip_registry.search(event.eeid)];
							point = event.point[0] + self.context["delta"][0], event.point[1] + self.context["delta"][1];
							point = self.parent.canvas_grid.snap_point(point);
							self._move_text(text, point);
	
	def tick(self):
		if self.texts == None:
			return;
		
		self._synchronize_manip();
		self.canvas_manip.tick();
		self._handle_events();

class DoorEditor:
	class Door:
		def __init__(self, scene, entity):
			self.scene = scene;
			self.entity = entity;
			self.pointers = [];
		
		def update(self, doors):
			for door in doors:
				if door is self:
					continue;
				to_scene = get_script_data(door.entity, "to_scene");
				if to_scene == None or to_scene["value"] != self.scene["name"]:
					continue;
				to_entity = get_script_data(door.entity, "to_entity");
				if to_entity == None or to_entity["value"] != self.entity["name"]:
					continue;
				self.pointers.append(door);
	
		def points_to(self):
			to_scene = get_script_data(self.entity, "to_scene");
			to_entity = get_script_data(self.entity, "to_entity");
			return to_scene["value"] != "" and to_entity["value"] != "";

		def is_pointed_to(self):
			return len(self.pointers) > 0;

	class Selector:
		def __init__(self, parent, door):
			self.parent = parent;
			self.door = door;
			self.open = True;

		def draw(self):
			_, self.open = imgui.begin("Select door", self.open);
			for scene in self.parent.door_hierarchy:
				if imgui.tree_node(f"{scene}##{id(scene)}"):
					for door in self.parent.door_hierarchy[scene]:
						if door == self.door:
							continue;
						to_scene = get_script_data(self.door.entity, "to_scene");
						to_entity = get_script_data(self.door.entity, "to_entity");
						was_selected = door.entity["name"] == to_entity["value"];
						clicked, value = imgui.menu_item(f"{door.entity["name"]}##{id(door.entity)}", "", was_selected);
						if clicked:
							if was_selected:
								to_scene["value"] = "";
								to_entity["value"] = "";
							else:
								to_scene["value"] = door.scene["name"];
								to_entity["value"] = door.entity["name"];
					imgui.tree_pop();
			imgui.end();
	
	def __init__(self, parent):
		self.parent = parent;
		self.door_pool = [];
		self.door_hierarchy = {};

		self.selector = None;
	
	def poll_all_doors(self):
		self.door_pool = [];
		self.door_hierarchy = {};
		for scene in AssetManager.get_all("scene"):
			self.door_hierarchy[scene["name"]] = [];
			for entity in scene["entities"]:
				prototype = AssetManager.search("prototype", entity["prototype"]);
				if prototype == None:
					continue;
				if "door" in prototype["scripts"]:
					door = DoorEditor.Door(scene, entity);
					self.door_pool.append(door);
					self.door_hierarchy[scene["name"]].append(door);
	
	def logic(self):
		self.poll_all_doors();
		for door in self.door_pool:
			door.update(self.door_pool);
	
	def gui(self):
		for scene in self.door_hierarchy:
			if scene == self.parent.scene["name"]:
				for door in self.door_hierarchy[scene]:
					if imgui.tree_node(door.entity["name"]+"##"+str(id(door.entity))):
						to_scene = get_script_data(door.entity, "to_scene");
						to_entity = get_script_data(door.entity, "to_entity");
						if AssetManager.search("scene", to_scene["value"]) == None:
							to_scene["value"] = "";
						elif next((x for x in AssetManager.search("scene", to_scene["value"])["entities"] if x["name"] == to_entity["value"]), None) == None:
							to_entity["value"] = "";
						
						if to_scene["value"] == "":
							imgui.text("Unlinked");
						elif to_entity["value"] == "":
							imgui.text(f"Linked to scene {to_scene["value"]}");
						else:
							imgui.text(f"Linked to {to_scene["value"]}.{to_entity["value"]}");
						
						imgui.same_line();
						if imgui.button("Browse"):
							self.selector = DoorEditor.Selector(self, door);
						
						orientation = get_script_data(door.entity, "orientation");
						orientation["value"] = input_orientation("Orientation", orientation["value"]);
						
						imgui.tree_pop();		

		if self.selector != None:
			self.selector.draw();
			if not self.selector.open:
				self.selector = None;

	def draw(self):
		for scene in self.door_hierarchy:
			if scene == self.parent.scene["name"]:
				for door in self.door_hierarchy[scene]:
					door_gizmo = SpriteBank.search("editor_door");
					x, y = door.entity["position"];

					prototype = AssetManager.search("prototype", door.entity["prototype"]);
					if prototype["has_trigger"]:
						x0, y0, x1, y1 = prototype["trigger"];
						w, h = x1-x0, y1-y0;
						x = x + x0 + w/2;
						y = y + y1;
					
					idx = 0;
					if door.points_to() and not door.is_pointed_to():
						idx = 1;
					if door.is_pointed_to() and not door.points_to():
						idx = 2;
					if door.points_to() and door.is_pointed_to():
						idx = 3;
					self.parent.canvas.draw_image(x-door_gizmo.frame_width/2, y-door_gizmo.frame_height, door_gizmo.frame_images[idx]);

					arrow_gizmo = SpriteBank.search("editor_arrow");
					orientation = get_script_data(door.entity, "orientation");
					x_off = -arrow_gizmo.frame_width/2;
					y_off = -door_gizmo.frame_height/2-arrow_gizmo.frame_height/2;
					match orientation["value"]:
						case 1:
							x_off += door_gizmo.frame_width/2+arrow_gizmo.frame_width/2;
						case 2:
							y_off -= door_gizmo.frame_height/2+arrow_gizmo.frame_height/2;
						case 3:
							x_off -= door_gizmo.frame_width/2+arrow_gizmo.frame_width/2;
						case 4:
							y_off += door_gizmo.frame_height/2+arrow_gizmo.frame_height/2;
					self.parent.canvas.draw_image(x+x_off, y+y_off, arrow_gizmo.frame_images[orientation["value"]], c=(255, 128, 0));

class NavlistEditor:
	class Navlist:
		def __init__(self, entity):
			self.entity = entity;
			self.asset = AssetManager.search("navlist", get_script_data(entity, "navlist")["value"]);
		def __eq__(self, value):
			if not isinstance(value, NavlistEditor.Navlist):
				return False;
			return self.entity == value.entity;
		def get_anchor(self):
			return get_script_data(self.entity, "anchor")["value"];
		def set_anchor(self, anchor):
			get_script_data(self.entity, "anchor")["value"] = anchor;
		def get_aabb(self):
			ox, oy = self.get_anchor();
			x0, y0, x1, y1 = math.inf, math.inf, -math.inf, -math.inf;
			for node in self.asset["nodes"]:
				x, y = node["position"];
				x += ox;
				y += oy;
				x0 = min(x0, x);
				y0 = min(y0, y);
				x1 = max(x1, x);
				y1 = max(y1, y);
			return [x0, y0, x1, y1];
	
	class ManipIndex:
		def __init__(self, navlist, node_idx):
			self.navlist = navlist;
			self.node_idx = node_idx;
		def __eq__(self, value):
			if not isinstance(value, NavlistEditor.ManipIndex):
				return False;
			return self.navlist == value.navlist and self.node_idx == value.node_idx;

	class ManipMode(Enum):
		MOVE = 0,
		EDIT = 1

	def __init__(self, parent):
		self.parent = parent;
		self.navlists = [];
		self.event_queue = [];
		self.canvas_manip = CanvasManipulator(parent.canvas_io, self.event_queue);
		self.manip_registry = CanvasManipRegistry();
		self.selection_context = SelectionContext();
		self.manip_mode = NavlistEditor.ManipMode.MOVE;

	def poll_all_navlists(self):
		self.navlists = [];
		for entity in self.parent.scene["entities"]:
			navlist_data = get_script_data(entity, "navlist");
			if navlist_data == None:
				continue;
			self.navlists.append(NavlistEditor.Navlist(entity));
	
	def synchronize_manip(self):
		objects = [];
		shapes = [];

		match self.manip_mode:
			case NavlistEditor.ManipMode.MOVE:
				for navlist in self.navlists:
					objects.append(NavlistEditor.ManipIndex(navlist, 0));
				def make_shape(manip_idx):
					return CanvasManipRect(manip_idx.navlist.get_aabb());
				shapes = [make_shape(x) for x in objects];
			case NavlistEditor.ManipMode.EDIT:
				for navlist in self.navlists:
					for idx,node in enumerate(navlist.asset["nodes"]):
						objects.append(NavlistEditor.ManipIndex(navlist, idx));
				def make_shape(manip_idx):
					x0, y0 = manip_idx.navlist.get_anchor();
					node = manip_idx.navlist.asset["nodes"][manip_idx.node_idx];
					x, y = node["position"];
					return CanvasManipPoint([x0+x, y0+y], 8);
				shapes = [make_shape(x) for x in objects];
		
		self.manip_registry.update(objects, shapes);
		self.canvas_manip.synchronize(self.manip_registry);
	
	def logic(self):
		self.poll_all_navlists();
		self.synchronize_manip();
		self.canvas_manip.tick();

		while len(self.event_queue) > 0:
			event = self.event_queue.pop(0);

			if isinstance(event, CanvasManipClick):
				if event.eeid == None:
					self.selection_context.clear();
				else:
					idx = self.manip_registry.search(event.eeid);
					self.selection_context.select(idx, exclusive=True);

			if isinstance(event, CanvasManipDrag):
				if event.eeid == None:
					continue;
				if event.signal == CanvasManipDrag.Signal.TICK:
					idx = self.manip_registry.search(event.eeid);
					navlist = idx.navlist;
					node = navlist.asset["nodes"][idx.node_idx];
					match self.manip_mode:
						case NavlistEditor.ManipMode.MOVE:
							navlist.set_anchor(event.point);
						case NavlistEditor.ManipMode.EDIT:
							x0, y0 = navlist.get_anchor();
							x, y = event.point;
							node["position"] = self.parent.canvas_grid.snap_point((x-x0, y-y0));

	def draw_gui(self):
		selection = self.selection_context.get_selection(single=True);
		if selection != None:
			navlist = selection.navlist;
			idx = selection.node_idx;
			node = navlist.asset["nodes"][idx];
			imgui.text(f"{navlist.entity["name"]} ({idx})");

			self.manip_mode = input_enum("Mode", self.manip_mode, NavlistEditor.ManipMode);

			node["position"] = input_vec2("Position", node["position"]);
			node["wait_frames"] = input_int("Wait frames", node["wait_frames"]);

			if imgui.button("Insert after"):
				insert_idx = idx+1;
				insert_position = list(node["position"]);
				if insert_idx < len(navlist.asset["nodes"])-1:
					next_node = navlist.asset["nodes"][idx+1];
					delta = np.array(next_node["position"]) - np.array(insert_position);
					insert_position[0] += delta[0]/2;
					insert_position[1] += delta[1]/2;
				navlist.asset["nodes"].insert(insert_idx, {
					"position": insert_position,
					"wait_frames": 0
				});

	def draw_canvas(self):
		node_colour = (128, 255, 255);
		edge_colour = node_colour;
		special_colour = (0, 255, 255);

		selection = self.selection_context.get_selection(single=True);
		selected_navlist = selection.navlist if selection != None else None;

		for navlist in self.navlists:
			x0, y0 = navlist.get_anchor();
			V = navlist.asset["nodes"];
			N = len(V);

			for i in range(N):
				a = V[i]["position"];
				b = V[(i+1)%N]["position"];
				self.parent.canvas.draw_circle(x0+a[0], y0+a[1], 8, node_colour);
				if navlist == selected_navlist:
					if i == 0:
						self.parent.canvas.draw_circle(x0+a[0], y0+a[1], 12, special_colour);
					if i == selection.node_idx:
						self.parent.canvas.draw_circle(x0+a[0], y0+a[1], 12, (255, 255, 255));
				if i == N-1 and not navlist.asset["loop"]:
					break;
				self.parent.canvas.draw_line(x0+a[0], y0+a[1], x0+b[0], y0+b[1], edge_colour);
				self.parent.canvas.draw_circle(x0+b[0], y0+b[1], 8, node_colour);

		if self.manip_mode == NavlistEditor.ManipMode.MOVE and selected_navlist != None:
			self.parent.canvas.draw_aabb(selected_navlist.get_aabb(), (255, 255, 255));	

class SceneViewer:
	def __init__(self, parent):
		self.parent = parent;

		self.show_tiles = True;
		self.show_entities = True;
		self.show_texts = True;

		self.show_grid = False;
		self.show_walls = True;
		self.show_boxes = False;
		self.show_gizmos = True;
	
	def draw_entities(self):
		def sort_y(entity):
			base_y = get_entity_aabb(entity)[3];
			prototype = AssetManager.search("prototype", entity["prototype"]);
			y_offset = prototype["y_sort_offset"] if prototype != None else 0;
			return base_y+y_offset;
		y_sorted = self.parent.scene["entities"];
		y_sorted = sorted(y_sorted, key=sort_y);

		for entity in y_sorted:
			prototype = AssetManager.search("prototype", entity["prototype"]);
			sprite = SpriteBank.search(prototype["sprite"], safe=False) if prototype != None else None;

			x, y = entity["position"];
			dx, dy = prototype["sprite_offset"] if prototype != None else (0, 0);
			aabb = get_entity_aabb(entity);
			
			if sprite != None:
				frame_idx = clamp(entity["frame_idx"], 0, sprite.frame_count-1);
				self.parent.canvas.draw_image(x+dx, y+dy, sprite.frame_images[frame_idx]);
			else:
				self.parent.canvas.draw_aabb(aabb, (255, 255, 0));

			if prototype != None and self.show_boxes:
				if prototype["has_blocker"]:
					colour = (255, 0, 0);
					x0, y0, x1, y1 = prototype["blocker"];
					x0, y0, x1, y1 = x0+x, y0+y, x1+x, y1+y;
					self.parent.canvas.draw_aabb((x0, y0, x1, y1), colour);
				if prototype["has_trigger"]:
					colour = (0, 255, 0);
					x0, y0, x1, y1 = prototype["trigger"];
					x0, y0, x1, y1 = x0+x, y0+y, x1+x, y1+y;
					self.parent.canvas.draw_aabb((x0, y0, x1, y1), colour);				

			if self.parent.selection_context.is_selected(entity):
				self.parent.canvas.draw_aabb(aabb, (255, 255, 255));
				self.parent.canvas.draw_circle(x, y, 4, (192, 192, 255));
	
	def draw_texts(self):
		for text in self.parent.scene["texts"]:
			self.parent.canvas.draw_text(text["position"], text["text"], 8*text["scale"], text["colour"]);
			self.parent.canvas.draw_aabb(get_text_aabb(text), (255, 255, 255));
	
	def draw_walls(self):
		if self.parent.scene["has_bounds"]:
			self.parent.canvas.draw_aabb(self.parent.scene["bounds"], (128, 0, 0), False);
		
		for wall in self.parent.scene["walls"]:
			colour = (255, 255, 0) if self.parent.wall_editor.selection_context.is_selected(wall) else (255, 0, 0);
			scenes.walls.canvas_draw(self.parent.canvas, wall, colour);
		
		self.parent.wall_editor.canvas_manip.draw(self.parent.canvas, (255, 255, 255));
	
	def draw(self):
		self.parent.canvas.clear(tuple(self.parent.scene["background"]));

		if self.show_tiles:
			for tilemap in self.parent.scene["tilemaps"]:
				scenes.tilemaps.canvas_draw(self.parent.canvas, tilemap, self.parent.tilemap_editor.cursor);
		if self.show_grid:
			self.parent.canvas_grid.draw_lines((64, 64, 64));
		self.parent.canvas.draw_guides((128, 128, 128));
		
		if self.show_entities:
			self.draw_entities();
		if self.show_texts:
			self.draw_texts();
		if self.show_walls:
			self.draw_walls();

		if self.show_gizmos:
			self.parent.door_editor.draw();
			self.parent.navlist_editor.draw_canvas();

class SceneEditor:
	def _load_scene(self, scene):		
		self.scene = scene;

		self.event_queue.clear();
		self.canvas_manip.clear();
		self.manip_registry.clear();

		self.selection_context.clear();
		
		self.tilemap_editor.on_load_scene();
		self.wall_editor.on_load_scene();
		self.text_editor.on_load_scene();

	def _is_scene_loaded(self):
		return self.scene in AssetManager.get_all("scene");

	def __init__(self):
		self.canvas_size = (1000, 720);
		self.canvas = Canvas(self.canvas_size[0], self.canvas_size[1], origin=(self.canvas_size[0]//2, self.canvas_size[1]//2));
		self.canvas_io = CanvasIO(self.canvas);
		self.canvas_grid = CanvasGrid(
			self.canvas,
			4
		);

		self.event_queue = [];
		self.canvas_manip = CanvasManipulator(self.canvas_io, self.event_queue);
		self.manip_registry = CanvasManipRegistry();

		self.selection_context = SelectionContext();
		self.clipboard = Clipboard();
		self.trash = Trash(deferred=True);

		self.edit_mode = EditMode.ENTITIES;
		self.snap = True;

		self.tilemap_editor = TilemapEditor(self);
		self.wall_editor = WallEditor(self);
		self.text_editor = TextEditor(self);
		self.door_editor = DoorEditor(self);
		self.navlist_editor = NavlistEditor(self);
		self.scene_viewer = SceneViewer(self);

		self._load_scene(AssetManager.get_first("scene"));
	
	def view_drag_handler(self, event):
		match event.signal:
			case CanvasManipDrag.Signal.TICK:
				x0, y0 = event.start;
				x, y = event.point;
				dx, dy = x-x0, y-y0;
				
				ox, oy = self.canvas.origin;
				self.canvas.origin = ox+dx, oy+dy;

	def handle_events(self):
		while len(self.event_queue) > 0:
			event = self.event_queue.pop(0);

			if isinstance(event, CanvasManipClick):
				if event.eeid == None:
					self.selection_context.clear();
				else:
					entity = self.manip_registry.search(event.eeid);
					self.selection_context.select(entity, exclusive=True);
			
			if isinstance(event, CanvasManipDrag):
				if event.eeid != None:
					match event.signal:
						case CanvasManipDrag.Signal.TICK:
							entity = self.selection_context.get_selection(single=True);
							point = event.point;
							delta = event.delta;
							position = point[0]+delta[0], point[1]+delta[1];
							if self.snap:
								position = self.canvas_grid.snap_point(position);
							entity["position"] = position;
				else:
					self.view_drag_handler(event);
	
	def get_entity_sprite(self, entity):
		prototype = AssetManager.search("prototype", entity["prototype"]);
		return SpriteBank.search(prototype["sprite"] if prototype != None else "null");
	
	def synchronize_manip(self):
		def make_shape(entity):
			aabb = get_entity_aabb(entity);
			return CanvasManipRect(aabb);
		shapes = [make_shape(x) for x in self.scene["entities"]];
		
		self.manip_registry.update(self.scene["entities"], shapes);
		self.canvas_manip.synchronize(self.manip_registry);
	
	def draw_menu_bar(self):
		if imgui.begin_menu_bar():

			if imgui.begin_menu("Scene"):
				if imgui.begin_menu("Open"):
					scenes = AssetManager.get_all("scene");
					scene_last = self.scene;
					for scene in scenes:
						if imgui.menu_item_simple(scene["name"]):
							self.scene = scene;
					if self.scene != scene_last:
						self._load_scene(self.scene);
					imgui.end_menu();
				imgui.end_menu();
			
			if imgui.begin_menu("View"):
				_, self.scene_viewer.show_tiles = imgui.menu_item("Tiles", "", self.scene_viewer.show_tiles);
				_, self.scene_viewer.show_entities = imgui.menu_item("Entities", "", self.scene_viewer.show_entities);
				_, self.scene_viewer.show_texts = imgui.menu_item("Texts", "", self.scene_viewer.show_texts);
				_, self.scene_viewer.show_boxes = imgui.menu_item("Boxes", "", self.scene_viewer.show_boxes);
				_, self.scene_viewer.show_walls = imgui.menu_item("Walls", "", self.scene_viewer.show_walls);
				_, self.scene_viewer.show_gizmos = imgui.menu_item("Gizmos", "", self.scene_viewer.show_gizmos);
				_, self.scene_viewer.show_grid = imgui.menu_item("Grid", "", self.scene_viewer.show_grid);
				imgui.end_menu();
			
			if imgui.begin_menu("Grid"):
				imgui.set_next_item_width(64);
				self.canvas_grid.size = input_int("Size", self.canvas_grid.size, style=EEGUIIntStyle.SLIDER, low_bound=2, high_bound=16);
				self.snap = input_bool("Snap", self.snap);
				imgui.end_menu();
			
			imgui.end_menu_bar();		
	
	def gui_draw_entities(self):	
		for entity in self.scene["entities"]:
			name = entity["name"] if len(entity["name"]) > 0 else str(id(entity));
			sprite = self.get_entity_sprite(entity);

			imgui.set_next_item_open(self.selection_context.is_selected(entity));
			node_open = imgui.tree_node(f"{name}####{id(entity)}");

			if imgui.begin_popup_context_item():
				if imgui.menu_item_simple("Delete"):
					self.trash.trash_item(self.scene["entities"], entity);
					imgui.close_current_popup();
				imgui.end_popup();
			
			if node_open:
				self.selection_context.select(entity, exclusive=True);
				
				entity["name"] = input_string("Name", entity["name"]);
				imgui.same_line();
				entity["enabled"] = input_bool("##enabled", entity["enabled"]);
				entity["prototype"] = input_asset("Prototype", entity["prototype"], "prototype");
				if len(entity["prototype"]) > 0 and len(entity["name"]) <= 0:
					entity["name"] = entity["prototype"];

				entity["frame_idx"] = input_int("Frame", entity["frame_idx"], EEGUIIntStyle.SLIDER, 0, sprite.frame_count-1);
				
				if imgui.tree_node("Script data"):
					for sd_inst in entity["script_data"]:
						sd = scripts.ScriptData(sd_inst["signature"]["key"], sd_inst["signature"]["type"]);
						if imgui.tree_node(f"{sd.key}"):
							sd_inst["value"] = typed_input(f"##{sd.key}", sd.type, sd_inst["value"]);
							imgui.tree_pop();
					if imgui.button("Reset to defaults"):
						entity["script_data"] = [];
					imgui.tree_pop();
				imgui.tree_pop();
	
	def gui_draw_properties_editor(self):
		self.scene["has_background"] = input_bool("Has background", self.scene["has_background"]);
		if self.scene["has_background"]:
			self.scene["background"] = input_colour("Background", self.scene["background"]);
		self.scene["has_bounds"] = input_bool("Has bounds", self.scene["has_bounds"]);
		if self.scene["has_bounds"]:
			self.scene["bounds"] = input_aabb("Bounds", self.scene["bounds"]);
		self.scene["free_camera"] = input_bool("Free camera", self.scene["free_camera"]);
	
	def scene_context_menu(self):
		if self.edit_mode == EditMode.ENTITIES:
			selection = self.selection_context.get_selection(single=True);
			hovered = selection != None and aabb_contains_point(get_entity_aabb(selection), self.canvas_io.get_cursor());
			if hovered:
				if imgui.menu_item_simple("Delete"):
					self.trash.trash_item(self.scene["entities"], selection);
			
			if imgui.menu_item_simple("Spawn"):
				print(AssetManager.get_tree("scene").search("entities"));
				entity = AssetManager.get_tree("scene").search("entities").inmost.prototype();
				entity["name"] = "";
				entity["position"] = self.canvas_io.get_cursor();
				self.scene["entities"].append(entity);

	def draw(self):
		self.draw_menu_bar();

		if not self._is_scene_loaded():
			return;

		self.canvas_io.tick();
		self.synchronize_manip();
		
		for entity in self.scene["entities"]:
			scripts.rectify_entity(entity);

		def run_left_panel(panel_tick):
			imgui.begin_child(
				"left-panel",
				imgui.ImVec2((imgui.get_content_region_avail().x - self.canvas.width) * 0.9, imgui.get_content_region_avail().y),
				0, 0
			);
			panel_tick();
			imgui.end_child();
		
		def entities_tick():
			if InputManager.is_command(glfw.KEY_C):
				self.clipboard.copy(self.selection_context.get_selection(single=True), copy_mode=Clipboard.CopyMode.DEEP, exclusive=True);
			if InputManager.is_command(glfw.KEY_V):
				self.clipboard.paste(self.scene["entities"]);
			
			if InputManager.is_command(glfw.KEY_D):
				selection = self.selection_context.get_selection(single=True);
				if selection != None:
					self.trash.trash_item(self.scene["entities"], selection);
			if InputManager.is_command(glfw.KEY_Z):
				self.trash.restore();
			
			self.canvas_manip.tick();
			self.handle_events();

			self.gui_draw_entities();
			self.trash.flush();

		def tilemap_tick():
			self.tilemap_editor.tick();
			self.tilemap_editor.draw_gui();
		
		def walls_tick():
			self.wall_editor.tick();
			self.wall_editor.draw_gui();
		
		def doors_tick():
			self.door_editor.logic();
			self.door_editor.gui();
		
		def navlists_tick():
			self.navlist_editor.logic();
			self.navlist_editor.draw_gui();
		
		def texts_tick():
			self.text_editor.tick();
			self.text_editor.draw_gui();
		
		def properties_tick():
			self.gui_draw_properties_editor();
		
		match self.edit_mode:
			case EditMode.ENTITIES:
				run_left_panel(entities_tick);
			case EditMode.TILEMAP:
				run_left_panel(tilemap_tick);
			case EditMode.WALLS:
				run_left_panel(walls_tick);
			case EditMode.DOORS:
				run_left_panel(doors_tick);
			case EditMode.NAVLISTS:
				run_left_panel(navlists_tick);
			case EditMode.TEXTS:
				run_left_panel(texts_tick);
			case EditMode.PROPERTIES:
				run_left_panel(properties_tick);	

		imgui.same_line();
		imgui.begin_child(
			"main-panel",
			imgui.ImVec2(imgui.get_content_region_avail().x, imgui.get_content_region_avail().y),
			0, 0
		);

		if imgui.begin_tab_bar("edit-mode"):
			for value in EditMode:
				tab_visible, tab_open = imgui.begin_tab_item(value.name);
				if tab_visible:
					self.edit_mode = value;
					imgui.end_tab_item();
			imgui.end_tab_bar();

		self.scene_viewer.draw();
		self.canvas.render(gui_id="canvas");
		if ContextMenu.begin("canvas"):
			self.scene_context_menu();
			imgui.end_popup();
		
		imgui.end_child();
		