from imgui_bundle import imgui;
import glfw;
import csv;
import copy;

from cowtools import *;
from canvas import *;
from assets import *;
from sprites import SpriteBank;
from input import InputManager;
from editor_gui import *;
from geometry import *;
import scenes.walls;
import paths;
import scenes.tilemaps;
import scenes.navlists;
import scenes.decorations;
import scenes.entities;
import scenes.foliage;
import scripts;

#########################################################
## HELPERS

# a pasted copy lands this far from the original, stepping further out with
# each paste so repeats don't stack on one spot
PASTE_OFFSET = 16;

# zoom multiplier per wheel notch; trackpads deliver fractional notches
ZOOM_STEP = 1.1;

def index_of(items, item):
	return next((i for i, x in enumerate(items) if x is item), None);

get_entity_sprite = scenes.entities.get_sprite;
get_entity_aabb = scenes.entities.get_aabb;
get_entity_body_key = scenes.entities.get_body_key;
get_entity_depth = scenes.entities.get_depth;

def get_script_data(entity, key):
	for entry in entity["script_data"]:
		for datum in entry["data"]:
			if datum["signature"]["key"] == key:
				return datum;
	return None;

#########################################################
## SCENE EDITOR

class EditMode(Enum):
	ENTITIES = 0,
	TILEMAP = 1,
	WALLS = 2,
	DOORS = 3,
	NAVLISTS = 4,
	DECORATIONS = 5,
	PROPERTIES = 6,
	FOLIAGE = 7

class TilemapEditor:
	TOOLS = ["paint", "rect", "fill"];

	def __init__(self, parent):
		self.parent = parent;
		self.tilemaps = None;
		self.tilemap = None;

		self.event_queue = [];
		self.canvas_manip = CanvasManipulator(self.parent.canvas_io, self.event_queue);

		self.tool = "paint";
		self.selected_frame = 0;
		self.cursor = None;
		self.rect_anchor = None;
		self.paint_last = None;

	def on_load_scene(self):
		self.tilemaps = self.parent.scene["tilemaps"];
		self.tilemap = self.tilemaps[0] if len(self.tilemaps) > 0 else None;
		self.canvas_manip.clear();
		self.rect_anchor = None;
		self.paint_last = None;

	def validate(self):
		# the scene's list and its contents can be swapped out under us by an undo
		self.tilemaps = self.parent.scene["tilemaps"];
		if index_of(self.tilemaps, self.tilemap) == None:
			self.tilemap = self.tilemaps[0] if len(self.tilemaps) > 0 else None;
			self.rect_anchor = None;
			self.paint_last = None;

	def create_tilemap(self):
		tilemap = AssetManager.get_tree("scene").search("tilemaps").inmost.prototype();
		self.tilemaps.append(tilemap);
		self.tilemap = tilemap;

	def delete_tilemap(self):
		idx = index_of(self.tilemaps, self.tilemap);
		if idx == None:
			return;
		del self.tilemaps[idx];
		self.tilemap = self.tilemaps[min(idx, len(self.tilemaps)-1)] if len(self.tilemaps) > 0 else None;
		self.rect_anchor = None;
		self.paint_last = None;

	def move_tilemap(self, delta):
		# draw order is list order, so a move changes what draws over what
		idx = index_of(self.tilemaps, self.tilemap);
		if idx == None:
			return;
		target = idx + delta;
		if target < 0 or target >= len(self.tilemaps):
			return;
		self.tilemaps[idx], self.tilemaps[target] = self.tilemaps[target], self.tilemaps[idx];

	def label_tilemap(self, tilemap):
		if tilemap == None:
			return "None";
		idx = index_of(self.tilemaps, tilemap);
		palette = tilemap["palette"] if len(tilemap["palette"]) > 0 else "no palette";
		tags = ["fg" if tilemap["is_foreground"] else "bg"];
		if tilemap["is_animated"]:
			tags.append("anim");
		return f"{idx}: {palette} ({", ".join(tags)})";

	def draw_palette(self):
		self.tilemap["palette"] = input_asset("Palette", self.tilemap["palette"], "sprite");

		sprite = SpriteBank.search(self.tilemap["palette"]);
		if sprite == None:
			return;
	
		wdw_w = imgui.get_content_region_avail().x;
		cols = max(int(wdw_w // 72), 1);
		rows = int(math.ceil(sprite.frame_count / cols));

		i = 0;
		for r in range(rows):
			for c in range(cols):
				if i < sprite.frame_count:
					tint = (0.5, 0.5, 0.5, 1) if i == self.selected_frame else (1, 1, 1, 1);
					if imgui.image_button(f"##{i}", imgui.ImTextureRef(sprite.frames[i].handle), (64, 64), tint_col=tint):
						self.selected_frame = i;
					imgui.same_line();
				i += 1;
			imgui.new_line();
	
	def draw_gui(self):
		self.validate();

		if imgui.button("New"):
			self.create_tilemap();
		if self.tilemap != None:
			imgui.same_line();
			if imgui.button("Delete"):
				self.delete_tilemap();

		self.tilemap = combo("Tilemap", self.tilemap, self.tilemaps, self.label_tilemap);
		if self.tilemap == None:
			return;

		# later tilemaps draw on top of earlier ones within their layer
		if imgui.arrow_button("tilemap-up", imgui.Dir.up):
			self.move_tilemap(-1);
		imgui.same_line();
		if imgui.arrow_button("tilemap-down", imgui.Dir.down):
			self.move_tilemap(1);
		imgui.same_line();
		imgui.text_disabled("order (later draws on top)");

		type_last = self.tilemap["type"];
		self.tilemap["type"] = input_enum("Type", self.tilemap["type"], ["sparse", "dense"]);
		if type_last == "sparse" and self.tilemap["type"] == "dense":
			self.tilemap["dense"] = scenes.tilemaps.sparse_to_dense(self.tilemap["sparse"]);
		if type_last == "dense" and self.tilemap["type"] == "sparse":
			self.tilemap["sparse"] = scenes.tilemaps.dense_to_sparse(self.tilemap["dense"]);
		
		if self.tilemap["type"] == "dense":
			dense = self.tilemap["dense"];
			dense["position"] = input_vec2("Position", dense["position"]);
			rows = input_int("Rows", dense["rows"], low_bound=0);
			columns = input_int("Columns", dense["columns"], low_bound=0);
			if rows != dense["rows"] or columns != dense["columns"] or len(dense["frame_indices"]) != rows*columns:
				scenes.tilemaps.resize_dense(dense, rows, columns);
		
		self.tilemap["is_foreground"] = input_bool("Is Foreground", self.tilemap["is_foreground"]);

		# the palette plays as one animation over every placed tile
		self.tilemap["is_animated"] = input_bool("Is Animated", self.tilemap["is_animated"]);
		if self.tilemap["is_animated"]:
			imgui.same_line();
			imgui.set_next_item_width(96);
			self.tilemap["period"] = input_int("Period (ticks/frame)", self.tilemap["period"], low_bound=1);

		self.tool = input_enum("Tool", self.tool, TilemapEditor.TOOLS);
		imgui.text_disabled("shift: erase, alt: pick, right drag: pan");

		self.draw_palette();

		self.tilemap["csv"] = input_file("CSV", self.tilemap["csv"], "*.csv", root="assets/scenes/tilemaps");
		csv_path = paths.resolve(self.tilemap["csv"]) if self.tilemap["csv"] else None;
		if imgui.button("Import"):
			scenes.tilemaps.import_tilemap(self.tilemap, csv_path);
		imgui.same_line();
		if imgui.button("Export"):
			scenes.tilemaps.export_tilemap(self.tilemap, csv_path);

	def handle_events(self):
		while len(self.event_queue) > 0:
			event = self.event_queue.pop(0);

			if isinstance(event, CanvasManipViewDrag):
				CanvasManipulator.default_view_drag_handler(self.parent.canvas, event);
	
	def edit(self):
		if self.cursor == None:
			self.paint_last = None;
			if not InputManager.is_held(glfw.MOUSE_BUTTON_LEFT):
				self.rect_anchor = None;
			return;
	
		palette = SpriteBank.search(self.tilemap["palette"]);
		self.selected_frame = clamp(self.selected_frame, 0, palette.frame_count-1);
		col, row = scenes.tilemaps.world_to_cell(self.tilemap, *self.cursor);

		if InputManager.is_held(glfw.KEY_LEFT_ALT):
			self.paint_last = None;
			if InputManager.is_pressed(glfw.MOUSE_BUTTON_LEFT):
				frame_idx = scenes.tilemaps.get_tile(self.tilemap, col, row);
				if frame_idx != None:
					self.selected_frame = frame_idx;
			return;

		frame_idx = None if InputManager.is_held(glfw.KEY_LEFT_SHIFT) else self.selected_frame;

		paint_last = self.paint_last;
		self.paint_last = None;

		# painting past a dense map's edge grows it to reach the cell; growing
		# up or left moves the origin, so in-progress cells shift with it
		def grow_to(col, row, *others):
			if frame_idx == None or self.tilemap["type"] != "dense":
				return (col, row), others;
			dcol, drow = scenes.tilemaps.grow_dense(self.tilemap["dense"], col, row);
			shift = lambda cell: (cell[0]+dcol, cell[1]+drow) if cell != None else None;
			return shift((col, row)), tuple(shift(x) for x in others);

		match self.tool:
			case "paint":
				if InputManager.is_held(glfw.MOUSE_BUTTON_LEFT):
					(col, row), (paint_last,) = grow_to(col, row, paint_last);
					start = paint_last if paint_last != None else (col, row);
					scenes.tilemaps.stroke(self.tilemap, *start, col, row, frame_idx);
					self.paint_last = (col, row);

			case "rect":
				if InputManager.is_pressed(glfw.MOUSE_BUTTON_LEFT):
					self.rect_anchor = (col, row);
				if InputManager.is_released(glfw.MOUSE_BUTTON_LEFT) and self.rect_anchor != None:
					(col, row), (self.rect_anchor,) = grow_to(col, row, self.rect_anchor);
					self.rect_anchor, (cell,) = grow_to(*self.rect_anchor, (col, row));
					col, row = cell;
					scenes.tilemaps.fill_rect(self.tilemap, *self.rect_anchor, col, row, frame_idx);
					self.rect_anchor = None;

			case "fill":
				if InputManager.is_pressed(glfw.MOUSE_BUTTON_LEFT):
					scenes.tilemaps.flood_fill(self.tilemap, col, row, frame_idx);

	def draw_canvas(self):
		if self.tilemap == None or self.cursor == None:
			return;

		colour = (255, 255, 255);
		if InputManager.is_held(glfw.KEY_LEFT_ALT):
			colour = (128, 255, 128);
		elif InputManager.is_held(glfw.KEY_LEFT_SHIFT):
			colour = (255, 128, 128);

		col, row = scenes.tilemaps.world_to_cell(self.tilemap, *self.cursor);
		if self.rect_anchor != None:
			aabb = scenes.tilemaps.get_cell_aabb(self.tilemap, *self.rect_anchor, col, row);
		else:
			aabb = scenes.tilemaps.get_cell_aabb(self.tilemap, col, row);
		self.parent.canvas.draw_aabb(aabb, colour);

	def tick(self):
		self.validate();

		self.canvas_manip.tick();
		self.handle_events();

		if self.tilemap == None:
			self.cursor = None;
			return;

		if self.parent.canvas_io.is_cursor_in_bounds():
			self.cursor = self.parent.canvas_io.get_cursor();
		else:
			self.cursor = None;
		
		self.edit();

class WallEditor:
	def __init__(self, parent):
		self.parent = parent;
		self.walls = None;

		self.event_queue = [];
		self.canvas_manip = CanvasManipulator(self.parent.canvas_io, self.event_queue);
		self.manip_registry = CanvasManipRegistry();
		self.selection_context = SelectionContext();
		self.trash = Trash(deferred=True);

		self.place_mode = "none";

	def on_load_scene(self):
		self.walls = self.parent.scene["walls"];
		self.canvas_manip.clear();
		self.manip_registry.clear();
		self.selection_context.clear();
		self.trash.clear();
	
	def draw_gui(self):
		if self.walls == None:
			return;

		self.place_mode = input_enum("Place mode", self.place_mode, ["none", "aabb", "segment"]);

		for idx, wall in enumerate(self.walls):
			imgui.set_next_item_open(self.selection_context.is_selected(wall));
			node_open = imgui.tree_node(f"Wall {idx}##{id(self.walls)}{idx}");

			if imgui.begin_popup_context_item():
				if imgui.menu_item_simple("Delete"):
					self.trash.trash_index(self.walls, idx);
					imgui.close_current_popup();
				imgui.end_popup();
			self.trash.flush();

			if node_open:
				scenes.walls.gui_draw(wall);
				imgui.tree_pop();

	def synchronize_manip(self):
		def make_shape(wall):
			match wall["type"]:
				case "aabb":
					return CanvasManipRect(wall["aabb"]);
				case "segment":
					return CanvasManipSegment(wall["segment"]);
		shapes = [make_shape(x) for x in self.walls];
		
		self.manip_registry.update(self.walls, shapes);
		self.canvas_manip.synchronize(self.manip_registry);
	
	def handle_events(self):
		while len(self.event_queue) > 0:
			event = self.event_queue.pop(0);

			if isinstance(event, CanvasManipClick):
				hit = event.eeid != None;
				if hit:
					self.selection_context.select(self.manip_registry.search(event.eeid), exclusive=True);
					continue;
				if InputManager.is_held(glfw.KEY_LEFT_SHIFT):
					continue;
				
				new_wall = scenes.walls.canvas_place(event.point, self.place_mode, self.parent.canvas_grid);
				if new_wall != None:
					self.walls.append(new_wall);
					self.selection_context.select(new_wall);

			if isinstance(event, CanvasManipDrag):
				if event.eeid != None:
					wall = self.manip_registry.search(event.eeid);
					scenes.walls.canvas_drag(wall, event, self.parent.canvas_grid);

			if isinstance(event, CanvasManipViewDrag):
				CanvasManipulator.default_view_drag_handler(self.parent.canvas, event);
	
	def tick(self):
		if self.walls == None:
			return;
	
		if InputManager.is_command(glfw.KEY_D):
			selected = self.selection_context.get_selection(True);
			self.trash.trash_item(self.walls, selected);
			self.trash.flush();
			self.selection_context.clear();
		
		self.synchronize_manip();
		self.canvas_manip.tick();
		self.handle_events();

class DecorationEditor:
	def __init__(self, parent):
		self.parent = parent;
		self.decorations = None;

		self.event_queue = [];
		self.canvas_manip = CanvasManipulator(self.parent.canvas_io, self.event_queue);
		self.manip_registry = CanvasManipRegistry();
		self.selection_context = SelectionContext();
		self.clipboard = Clipboard();
		self.trash = Trash(deferred=True);

		self.place_mode = "none";

	def on_load_scene(self):
		self.decorations = self.parent.scene["decorations"];
		self.canvas_manip.clear();
		self.manip_registry.clear();
		self.selection_context.clear();
		self.trash.clear();

	def draw_gui(self):
		if self.decorations == None:
			return;

		self.place_mode = input_enum("Place mode", self.place_mode, ["none"] + scenes.decorations.TYPES);

		for idx, decoration in enumerate(self.decorations):
			imgui.set_next_item_open(self.selection_context.is_selected(decoration));
			node_open = imgui.tree_node(f"Decoration {idx}##{id(self.decorations)}{idx}");

			if imgui.begin_popup_context_item():
				if imgui.menu_item_simple("Delete"):
					self.trash.trash_index(self.decorations, idx);
					imgui.close_current_popup();
				imgui.end_popup();
			self.trash.flush();

			if node_open:
				scenes.decorations.gui_draw(decoration);
				imgui.tree_pop();

	def synchronize_manip(self):
		shapes = [scenes.decorations.make_manip(x) for x in self.decorations];
		keys = [scenes.decorations.get_body_key(x) for x in self.decorations];

		self.manip_registry.update(self.decorations, shapes, keys);
		self.canvas_manip.synchronize(self.manip_registry);

	def handle_events(self):
		while len(self.event_queue) > 0:
			event = self.event_queue.pop(0);

			if isinstance(event, CanvasManipClick):
				hit = event.eeid != None;
				if hit:
					self.selection_context.select(self.manip_registry.search(event.eeid), exclusive=True);
					continue;
				if InputManager.is_held(glfw.KEY_LEFT_SHIFT):
					continue;

				new_decoration = scenes.decorations.canvas_place(event.point, self.place_mode, self.parent.canvas_grid);
				if new_decoration != None:
					self.decorations.append(new_decoration);
					self.selection_context.select(new_decoration);

			if isinstance(event, CanvasManipDrag):
				if event.eeid != None:
					decoration = self.manip_registry.search(event.eeid);
					scenes.decorations.canvas_drag(decoration, event, self.parent.canvas_grid);

			if isinstance(event, CanvasManipViewDrag):
				CanvasManipulator.default_view_drag_handler(self.parent.canvas, event);

	def tick(self):
		if self.decorations == None:
			return;

		if InputManager.is_command(glfw.KEY_C):
			self.clipboard.copy(self.selection_context.get_selection(single=True), copy_mode=Clipboard.CopyMode.DEEP, exclusive=True);
		if InputManager.is_command(glfw.KEY_V):
			pasted = self.clipboard.paste(self.decorations);
			offset = PASTE_OFFSET * self.clipboard.paste_count;
			if len(pasted) > 0:
				self.selection_context.clear();
			for decoration in pasted:
				x, y = decoration["position"];
				scenes.decorations.relocate(decoration, self.parent.canvas_grid.snap_point((x+offset, y+offset)));
				self.selection_context.select(decoration);

		if InputManager.is_command(glfw.KEY_D):
			selected = self.selection_context.get_selection(True);
			self.trash.trash_item(self.decorations, selected);
			self.trash.flush();
			self.selection_context.clear();

		self.synchronize_manip();
		self.canvas_manip.tick();
		self.handle_events();

class DoorEditor:
	class Door:
		def __init__(self, scene, entity):
			self.scene = scene;
			self.entity = entity;
			self.pointers = [];
		
		def update(self, doors):
			for door in doors:
				if door is self:
					continue;
				to_scene = get_script_data(door.entity, "to_scene");
				if to_scene == None or to_scene["value"] != self.scene["name"]:
					continue;
				to_entity = get_script_data(door.entity, "to_entity");
				if to_entity == None or to_entity["value"] != self.entity["name"]:
					continue;
				self.pointers.append(door);
	
		def points_to(self):
			to_scene = get_script_data(self.entity, "to_scene");
			to_entity = get_script_data(self.entity, "to_entity");
			return to_scene["value"] != "" and to_entity["value"] != "";

		def is_pointed_to(self):
			return len(self.pointers) > 0;

	class Selector:
		def __init__(self, parent, door):
			self.parent = parent;
			self.door = door;
			self.open = True;

		def draw(self):
			_, self.open = imgui.begin("Select door", self.open);
			for scene in self.parent.door_hierarchy:
				if imgui.tree_node(f"{scene}##{id(scene)}"):
					for door in self.parent.door_hierarchy[scene]:
						if door == self.door:
							continue;
						to_scene = get_script_data(self.door.entity, "to_scene");
						to_entity = get_script_data(self.door.entity, "to_entity");
						was_selected = door.entity["name"] == to_entity["value"];
						clicked, value = imgui.menu_item(f"{door.entity["name"]}##{id(door.entity)}", "", was_selected);
						if clicked:
							if was_selected:
								to_scene["value"] = "";
								to_entity["value"] = "";
							else:
								to_scene["value"] = door.scene["name"];
								to_entity["value"] = door.entity["name"];
					imgui.tree_pop();
			imgui.end();
	
	def __init__(self, parent):
		self.parent = parent;
		self.door_pool = [];
		self.door_hierarchy = {};

		self.selector = None;
	
	def poll_all_doors(self):
		self.door_pool = [];
		self.door_hierarchy = {};
		for scene in AssetManager.get_all("scene"):
			self.door_hierarchy[scene["name"]] = [];
			for entity in scene["entities"]:
				prototype = AssetManager.search("prototype", entity["prototype"]);
				if prototype == None:
					continue;
				if "door" in prototype["scripts"]:
					door = DoorEditor.Door(scene, entity);
					self.door_pool.append(door);
					self.door_hierarchy[scene["name"]].append(door);
	
	def logic(self):
		self.poll_all_doors();
		for door in self.door_pool:
			door.update(self.door_pool);
	
	def gui(self):
		for scene in self.door_hierarchy:
			if scene == self.parent.scene["name"]:
				for door in self.door_hierarchy[scene]:
					if imgui.tree_node(door.entity["name"]+"##"+str(id(door.entity))):
						to_scene = get_script_data(door.entity, "to_scene");
						to_entity = get_script_data(door.entity, "to_entity");
						if AssetManager.search("scene", to_scene["value"]) == None:
							to_scene["value"] = "";
						elif next((x for x in AssetManager.search("scene", to_scene["value"])["entities"] if x["name"] == to_entity["value"]), None) == None:
							to_entity["value"] = "";
						
						if to_scene["value"] == "":
							imgui.text("Unlinked");
						elif to_entity["value"] == "":
							imgui.text(f"Linked to scene {to_scene["value"]}");
						else:
							imgui.text(f"Linked to {to_scene["value"]}.{to_entity["value"]}");
						
						imgui.same_line();
						if imgui.button("Browse"):
							self.selector = DoorEditor.Selector(self, door);
						
						orientation = get_script_data(door.entity, "orientation");
						orientation["value"] = input_orientation("Orientation", orientation["value"]);
						
						imgui.tree_pop();		

		if self.selector != None:
			self.selector.draw();
			if not self.selector.open:
				self.selector = None;

	def draw(self):
		for scene in self.door_hierarchy:
			if scene == self.parent.scene["name"]:
				for door in self.door_hierarchy[scene]:
					door_gizmo = SpriteBank.search("editor_door");
					x, y = door.entity["position"];

					prototype = AssetManager.search("prototype", door.entity["prototype"]);
					if prototype["has_trigger"]:
						x0, y0, x1, y1 = prototype["trigger"];
						w, h = x1-x0, y1-y0;
						x = x + x0 + w/2;
						y = y + y1;
					
					idx = 0;
					if door.points_to() and not door.is_pointed_to():
						idx = 1;
					if door.is_pointed_to() and not door.points_to():
						idx = 2;
					if door.points_to() and door.is_pointed_to():
						idx = 3;
					self.parent.canvas.draw_image(x-door_gizmo.width/2, y-door_gizmo.height, door_gizmo.frames[idx].source);

					arrow_gizmo = SpriteBank.search("editor_arrow");
					orientation = get_script_data(door.entity, "orientation");
					x_off = -arrow_gizmo.width/2;
					y_off = -door_gizmo.height/2-arrow_gizmo.height/2;
					match orientation["value"]:
						case 1:
							x_off += door_gizmo.width/2+arrow_gizmo.width/2;
						case 2:
							y_off -= door_gizmo.height/2+arrow_gizmo.height/2;
						case 3:
							x_off -= door_gizmo.width/2+arrow_gizmo.width/2;
						case 4:
							y_off += door_gizmo.height/2+arrow_gizmo.height/2;
					self.parent.canvas.draw_image(x+x_off, y+y_off, arrow_gizmo.frames[orientation["value"]].source, c=(255, 128, 0));

class NavlistEditor:
	# node_idx == None means the whole navlist is selected (as a body), rather
	# than any one node in it.
	class ManipIndex:
		def __init__(self, navlist, node_idx):
			self.navlist = navlist;
			self.node_idx = node_idx;
		def __eq__(self, value):
			if not isinstance(value, NavlistEditor.ManipIndex):
				return False;
			return self.navlist is value.navlist and self.node_idx == value.node_idx;

	# a click target for the connecting line from_idx -> from_idx+1; hitting one
	# inserts a node there rather than selecting anything
	class SegmentRef:
		def __init__(self, navlist, from_idx):
			self.navlist = navlist;
			self.from_idx = from_idx;
		def __eq__(self, value):
			if not isinstance(value, NavlistEditor.SegmentRef):
				return False;
			return self.navlist is value.navlist and self.from_idx == value.from_idx;

	def __init__(self, parent):
		self.parent = parent;
		self.navlists = None;

		self.event_queue = [];
		self.canvas_manip = CanvasManipulator(parent.canvas_io, self.event_queue);
		self.manip_registry = CanvasManipRegistry();
		self.selection_context = SelectionContext();
		self.clipboard = Clipboard();
		self.clipboard_kind = None;
		self.trash = Trash(deferred=True);

		self.place_mode = False;

	def on_load_scene(self):
		self.navlists = self.parent.scene["navlists"];
		self.canvas_manip.clear();
		self.manip_registry.clear();
		self.selection_context.clear();
		self.trash.clear();

	# Entities address navlists by position in this list, so a deletion has to
	# repoint everything above it.
	def _delete_navlist(self, idx):
		for entity in self.parent.scene["entities"]:
			datum = get_script_data(entity, "navlist_idx");
			if datum == None:
				continue;
			if datum["value"] == idx:
				datum["value"] = -1;
			elif datum["value"] > idx:
				datum["value"] -= 1;
		self.trash.trash_index(self.navlists, idx);

	# One pass over the whole scene registers a body (whole-list move), a
	# segment per connecting line (click-to-insert), and a point per node
	# (move that node) -- all at once, so there's no mode to switch between.
	# Keys break ties when they overlap: a node sitting on a segment wins the
	# segment, and either wins the body.
	def synchronize_manip(self):
		objects = [];
		shapes = [];
		keys = [];

		for navlist in self.navlists:
			nodes = navlist["nodes"];
			if len(nodes) == 0:
				continue;

			objects.append(NavlistEditor.ManipIndex(navlist, None));
			shapes.append(CanvasManipRect(scenes.navlists.get_aabb(navlist)));
			keys.append(0);

			for from_idx, segment in scenes.navlists.get_segments(navlist):
				objects.append(NavlistEditor.SegmentRef(navlist, from_idx));
				shapes.append(CanvasManipSegment(segment, radius=scenes.navlists.SEGMENT_RADIUS));
				keys.append(1);

			for idx, node in enumerate(nodes):
				objects.append(NavlistEditor.ManipIndex(navlist, idx));
				shapes.append(CanvasManipPoint(node["position"], scenes.navlists.NODE_RADIUS));
				keys.append(2);

		self.manip_registry.update(objects, shapes, keys);
		self.canvas_manip.synchronize(self.manip_registry);

	def handle_events(self):
		grid = self.parent.canvas_grid if self.parent.snap else None;

		while len(self.event_queue) > 0:
			event = self.event_queue.pop(0);

			if isinstance(event, CanvasManipClick):
				target = self.manip_registry.search(event.eeid) if event.eeid != None else None;

				if isinstance(target, NavlistEditor.SegmentRef):
					point = grid.snap_point(event.point) if grid else event.point;
					inserted = scenes.navlists.insert_node_after(target.navlist, target.from_idx, position=point);
					self.selection_context.select(NavlistEditor.ManipIndex(target.navlist, inserted), exclusive=True);
					continue;

				if target != None:
					self.selection_context.select(target, exclusive=True);
					continue;
				if not self.place_mode:
					self.selection_context.clear();
					continue;
				navlist = scenes.navlists.make(event.point, grid);
				self.navlists.append(navlist);
				self.selection_context.select(NavlistEditor.ManipIndex(navlist, 0), exclusive=True);

			if isinstance(event, CanvasManipViewDrag):
				CanvasManipulator.default_view_drag_handler(self.parent.canvas, event);
				continue;

			if isinstance(event, CanvasManipDrag):
				if event.eeid == None or event.signal != CanvasManipDrag.Signal.TICK:
					continue;
				target = self.manip_registry.search(event.eeid);
				if not isinstance(target, NavlistEditor.ManipIndex):
					continue;
				point = np.array(event.point) + np.array(event.delta);
				point = grid.snap_point(point) if grid else point;
				if target.node_idx == None:
					scenes.navlists.relocate(target.navlist, point);
				else:
					target.navlist["nodes"][target.node_idx]["position"] = list(point);

	def logic(self):
		if self.navlists == None:
			return;

		if InputManager.is_command(glfw.KEY_D):
			selection = self.selection_context.get_selection(single=True);
			if selection != None:
				if selection.node_idx != None:
					nodes = selection.navlist["nodes"];
					if len(nodes) > 1:
						self.trash.trash_index(nodes, selection.node_idx);
						self.selection_context.clear();
				elif selection.navlist in self.navlists:
					self._delete_navlist(self.navlists.index(selection.navlist));
					self.selection_context.clear();
			self.trash.flush();

		if InputManager.is_command(glfw.KEY_C):
			selection = self.selection_context.get_selection(single=True);
			if selection != None:
				if selection.node_idx != None:
					node = selection.navlist["nodes"][selection.node_idx];
					self.clipboard.copy(node, copy_mode=Clipboard.CopyMode.DEEP, exclusive=True);
					self.clipboard_kind = "node";
				else:
					self.clipboard.copy(selection.navlist, copy_mode=Clipboard.CopyMode.DEEP, exclusive=True);
					self.clipboard_kind = "navlist";

		if InputManager.is_command(glfw.KEY_V):
			if self.clipboard_kind == "navlist":
				pasted = self.clipboard.paste(self.navlists);
				offset = PASTE_OFFSET * self.clipboard.paste_count;
				if len(pasted) > 0:
					self.selection_context.clear();
				for navlist in pasted:
					scenes.navlists.translate(navlist, (offset, offset));
					self.selection_context.select(NavlistEditor.ManipIndex(navlist, None), exclusive=True);
			elif self.clipboard_kind == "node":
				selection = self.selection_context.get_selection(single=True);
				if selection != None:
					nodes = selection.navlist["nodes"];
					pasted = self.clipboard.paste(nodes);
					offset = PASTE_OFFSET * self.clipboard.paste_count;
					for node in pasted:
						node["position"][0] += offset;
						node["position"][1] += offset;
					if len(pasted) > 0:
						self.selection_context.select(NavlistEditor.ManipIndex(selection.navlist, nodes.index(pasted[-1])), exclusive=True);

		self.synchronize_manip();
		self.canvas_manip.tick();
		self.handle_events();

	def draw_gui(self):
		if self.navlists == None:
			return;

		self.place_mode = input_bool("Place mode", self.place_mode);

		selection = self.selection_context.get_selection(single=True);

		for idx, navlist in enumerate(self.navlists):
			selected = selection != None and selection.navlist is navlist;
			imgui.set_next_item_open(selected);
			label = navlist["name"] if navlist["name"] != "" else f"Navlist {idx}";
			node_open = imgui.tree_node(f"{label} ({idx})##{id(self.navlists)}{idx}");

			if imgui.begin_popup_context_item():
				if imgui.menu_item_simple("Delete"):
					self._delete_navlist(idx);
					self.selection_context.clear();
					imgui.close_current_popup();
				imgui.end_popup();
			self.trash.flush();

			if not node_open:
				continue;

			scenes.navlists.gui_draw(navlist);

			imgui.text("Nodes");
			nodes = navlist["nodes"];
			for node_idx, node in enumerate(nodes):
				node_selected = selected and selection.node_idx == node_idx;
				imgui.set_next_item_open(node_selected);
				node_row_open = imgui.tree_node(f"Node {node_idx}##{id(navlist)}{node_idx}");

				if imgui.begin_popup_context_item():
					if imgui.menu_item_simple("Move up") and node_idx > 0:
						nodes[node_idx-1], nodes[node_idx] = nodes[node_idx], nodes[node_idx-1];
						self.selection_context.select(NavlistEditor.ManipIndex(navlist, node_idx-1), exclusive=True);
						imgui.close_current_popup();
					if imgui.menu_item_simple("Move down") and node_idx < len(nodes)-1:
						nodes[node_idx+1], nodes[node_idx] = nodes[node_idx], nodes[node_idx+1];
						self.selection_context.select(NavlistEditor.ManipIndex(navlist, node_idx+1), exclusive=True);
						imgui.close_current_popup();
					if imgui.menu_item_simple("Insert after"):
						inserted = scenes.navlists.insert_node_after(navlist, node_idx);
						self.selection_context.select(NavlistEditor.ManipIndex(navlist, inserted), exclusive=True);
						imgui.close_current_popup();
					if imgui.menu_item_simple("Delete") and len(nodes) > 1:
						self.trash.trash_index(nodes, node_idx);
						self.selection_context.clear();
						imgui.close_current_popup();
					imgui.end_popup();
				self.trash.flush();

				if node_row_open:
					if not node_selected:
						self.selection_context.select(NavlistEditor.ManipIndex(navlist, node_idx), exclusive=True);
					scenes.navlists.gui_draw_node(node);
					imgui.tree_pop();

			imgui.tree_pop();

	def draw_canvas(self, show_selection=True):
		if self.navlists == None:
			return;

		colour = (128, 255, 255);
		selection = self.selection_context.get_selection(single=True);
		selected_navlist = selection.navlist if selection != None else None;

		for navlist in self.navlists:
			is_selected = navlist is selected_navlist;
			scenes.navlists.canvas_draw(
				self.parent.canvas, navlist, colour,
				selected_node=selection.node_idx if is_selected else None,
				highlight=(0, 255, 255) if is_selected else None
			);

		if show_selection and selected_navlist != None and selection.node_idx == None:
			self.parent.canvas.draw_aabb(scenes.navlists.get_aabb(selected_navlist), (255, 255, 255));

class SceneViewer:
	# Every toggleable thing the viewer draws, in menu order.
	# (key, menu label, shown by default, menu group)
	# Tool cursors (tilemap/foliage) are deliberately not here: they are
	# feedback for the active tool, not scene overlays.
	LAYERS = [
		("tiles",       "Tiles",                 True,  "Content"),
		("entities",    "Entities",              True,  "Content"),
		("decorations", "Decorations",           True,  "Content"),
		("walls",       "Walls",                 True,  "Collision"),
		("bounds",      "Scene bounds",          True,  "Collision"),
		("boxes",       "Blocker/trigger boxes", False, "Collision"),
		("doors",       "Door gizmos",           True,  "Gizmos"),
		("navlists",    "Navlists",              True,  "Gizmos"),
		("selection",   "Selection outlines",    True,  "Gizmos"),
		("grid",        "Grid",                  False, "Guides"),
		("guides",      "Axis guides",           True,  "Guides"),
	];
	CONTENT_GROUP = "Content";

	def __init__(self, parent):
		self.parent = parent;
		self.visible = {key: default for key, _, default, _ in SceneViewer.LAYERS};

	def shows(self, key):
		return self.visible[key];

	def show_all(self):
		for key in self.visible:
			self.visible[key] = True;

	def hide_overlays(self):
		for key, _, _, group in SceneViewer.LAYERS:
			if group != SceneViewer.CONTENT_GROUP:
				self.visible[key] = False;

	def draw_menu(self):
		last_group = None;
		for key, label, _, group in SceneViewer.LAYERS:
			if group != last_group:
				if last_group != None:
					imgui.separator();
				imgui.text_disabled(group);
				last_group = group;
			_, self.visible[key] = imgui.menu_item(label, "", self.visible[key]);
		imgui.separator();
		if imgui.menu_item_simple("Show all"):
			self.show_all();
		if imgui.menu_item_simple("Hide overlays"):
			self.hide_overlays();
	
	def draw_tilemaps(self, foreground):
		for tilemap in self.parent.scene["tilemaps"]:
			if tilemap["is_foreground"] == foreground:
				scenes.tilemaps.canvas_draw(self.parent.canvas, tilemap);

	def draw_entity(self, entity):
		prototype = AssetManager.search("prototype", entity["prototype"]);
		sprite = SpriteBank.search(prototype["sprite"], safe=False) if prototype != None else None;

		x, y = entity["position"];
		dx, dy = prototype["sprite_offset"] if prototype != None else (0, 0);

		if sprite != None:
			frame_idx = clamp(entity["frame_idx"], 0, sprite.frame_count-1);
			self.parent.canvas.draw_image(x+dx, y+dy, sprite.frames[frame_idx].source);
		else:
			self.parent.canvas.draw_aabb(get_entity_aabb(entity), (255, 255, 0));

	def draw_entity_overlays(self):
		for entity in self.parent.scene["entities"]:
			prototype = AssetManager.search("prototype", entity["prototype"]);
			x, y = entity["position"];

			if prototype != None and self.shows("boxes"):
				if prototype["has_blocker"]:
					x0, y0, x1, y1 = prototype["blocker"];
					self.parent.canvas.draw_aabb((x0+x, y0+y, x1+x, y1+y), (255, 0, 0));
				if prototype["has_trigger"]:
					x0, y0, x1, y1 = prototype["trigger"];
					self.parent.canvas.draw_aabb((x0+x, y0+y, x1+x, y1+y), (0, 255, 0));

			if self.shows("selection") and self.parent.selection_context.is_selected(entity):
				self.parent.canvas.draw_aabb(get_entity_aabb(entity), (255, 255, 255));
				self.parent.canvas.draw_circle(x, y, 4, (192, 192, 255));

	def draw_decoration_overlays(self):
		if not self.shows("selection"):
			return;
		for decoration in self.parent.scene["decorations"]:
			if self.parent.decoration_editor.selection_context.is_selected(decoration):
				self.parent.canvas.draw_aabb(scenes.decorations.get_aabb(decoration), (255, 255, 255));

	def draw_world(self):
		bodies = [];

		if self.shows("entities"):
			for entity in self.parent.scene["entities"]:
				bodies.append((get_entity_body_key(entity), lambda e=entity: self.draw_entity(e)));

		if self.shows("decorations"):
			for decoration in self.parent.scene["decorations"]:
				bodies.append((scenes.decorations.get_body_key(decoration), lambda d=decoration: scenes.decorations.canvas_draw(self.parent.canvas, d)));

		bodies = sorted(bodies, key=lambda x: x[0]);
		for _, draw_body in bodies:
			draw_body();

	def draw_bounds(self):
		if self.parent.scene["has_bounds"]:
			self.parent.canvas.draw_aabb(self.parent.scene["bounds"], (128, 0, 0), False);

	def draw_walls(self):
		for wall in self.parent.scene["walls"]:
			colour = (255, 255, 0) if self.parent.wall_editor.selection_context.is_selected(wall) else (255, 0, 0);
			scenes.walls.canvas_draw(self.parent.canvas, wall, colour);
	
	def draw(self):
		self.parent.canvas.clear(tuple(self.parent.scene["background"]));

		if self.shows("tiles"):
			self.draw_tilemaps(False);
		if self.shows("grid"):
			self.parent.canvas_grid.draw_lines((64, 64, 64));
		if self.shows("guides"):
			self.parent.canvas.draw_guides((128, 128, 128));

		self.draw_world();

		if self.shows("tiles"):
			self.draw_tilemaps(True);

		if self.shows("entities"):
			self.draw_entity_overlays();
		if self.shows("decorations"):
			self.draw_decoration_overlays();
		if self.shows("bounds"):
			self.draw_bounds();
		if self.shows("walls"):
			self.draw_walls();

		if self.shows("doors"):
			self.parent.door_editor.draw();
		if self.shows("navlists"):
			self.parent.navlist_editor.draw_canvas(show_selection=self.shows("selection"));

		if self.parent.edit_mode == EditMode.TILEMAP:
			self.parent.tilemap_editor.draw_canvas();
		if self.parent.edit_mode == EditMode.FOLIAGE:
			self.parent.foliage_editor.draw_canvas();

class SceneEditor:
	class SpawnPopup:
		def __init__(self, parent):
			self.parent = parent;
			self.is_open = False;
			self.prototype = "";
			self.position = None;
		
		def open(self):
			self.is_open = True;
			if self.parent.canvas_io.is_cursor_in_bounds():
				self.position = list(self.parent.canvas_io.get_cursor());
			else:
				self.position = [0, 0];

		def draw(self):
			if self.is_open:
				_, self.is_open = imgui.begin("Spawn", self.is_open);
				self.prototype = input_asset("##prototype", self.prototype, "prototype");
				if imgui.button("Spawn"):
					scenes.entities.spawn(self.parent.scene, self.prototype, self.position);
					self.is_open = False;
				imgui.same_line();
				if imgui.button("Cancel"):
					self.is_open = False;
				imgui.end();
	
	def _load_scene(self, scene):		
		self.scene = scene;
		self.scene.setdefault("script", "");

		self.event_queue.clear();
		self.canvas_manip.clear();
		self.manip_registry.clear();
		self.pan_event_queue.clear();
		self.pan_manip.clear();

		self.selection_context.clear();
		
		for entity in self.scene["entities"]:
			rectify_entity_script_data(entity);

		self.tilemap_editor.on_load_scene();
		self.wall_editor.on_load_scene();
		self.decoration_editor.on_load_scene();
		self.navlist_editor.on_load_scene();
		self.foliage_editor.on_load_scene();

	def _is_scene_loaded(self):
		return self.scene in AssetManager.get_all("scene");

	def __init__(self):
		self.canvas_size = (1000, 720);
		self.canvas = Canvas(self.canvas_size[0], self.canvas_size[1], origin=(self.canvas_size[0]//2, self.canvas_size[1]//2));
		self.canvas_io = CanvasIO(self.canvas);
		self.canvas_grid = CanvasGrid(
			self.canvas,
		    16
		);

		self.event_queue = [];
		self.canvas_manip = CanvasManipulator(self.canvas_io, self.event_queue);
		self.manip_registry = CanvasManipRegistry();

		# tabs with nothing to pick on the canvas still pan with this one; it
		# never gets shapes, so clicks are dropped and only view drags are kept
		self.pan_event_queue = [];
		self.pan_manip = CanvasManipulator(self.canvas_io, self.pan_event_queue);

		self.selection_context = SelectionContext();
		self.clipboard = Clipboard();
		self.trash = Trash(deferred=True);

		self.edit_mode = EditMode.ENTITIES;
		self.snap = True;
		self.entity_search = "";

		self.rename_target = None;
		self.rename_buffer = "";
		self.rename_pending = False;

		self.tilemap_editor = TilemapEditor(self);
		self.wall_editor = WallEditor(self);
		self.decoration_editor = DecorationEditor(self);
		self.door_editor = DoorEditor(self);
		self.navlist_editor = NavlistEditor(self);
		self.foliage_editor = scenes.foliage.FoliageEditor(self);
		self.scene_viewer = SceneViewer(self);

		self.spawn_popup = SceneEditor.SpawnPopup(self);

		self._load_scene(AssetManager.get_first("scene"));

	def handle_events(self):
		while len(self.event_queue) > 0:
			event = self.event_queue.pop(0);

			if isinstance(event, CanvasManipClick):
				if event.eeid == None:
					self.selection_context.clear();
				else:
					entity = self.manip_registry.search(event.eeid);
					self.selection_context.select(entity, exclusive=True);
			
			if isinstance(event, CanvasManipDrag):
				if event.eeid != None:
					match event.signal:
						case CanvasManipDrag.Signal.TICK:
							entity = self.selection_context.get_selection(single=True);
							point = event.point;
							delta = event.delta;
							position = point[0]+delta[0], point[1]+delta[1];
							if self.snap:
								position = self.canvas_grid.snap_point(position);
							entity["position"] = position;
			
			if isinstance(event, CanvasManipViewDrag):
				CanvasManipulator.default_view_drag_handler(self.canvas, event);

	def pan_tick(self):
		self.pan_manip.tick();
		while len(self.pan_event_queue) > 0:
			event = self.pan_event_queue.pop(0);
			if isinstance(event, CanvasManipViewDrag):
				CanvasManipulator.default_view_drag_handler(self.canvas, event);
	
	def get_entity_sprite(self, entity):
		prototype = AssetManager.search("prototype", entity["prototype"]);
		return SpriteBank.search(prototype["sprite"] if prototype != None else "null");
	
	def synchronize_manip(self):
		def make_shape(entity):
			aabb = get_entity_aabb(entity);
			return CanvasManipRect(aabb);
		shapes = [make_shape(x) for x in self.scene["entities"]];
		keys = [get_entity_body_key(x) for x in self.scene["entities"]];
		
		self.manip_registry.update(self.scene["entities"], shapes, keys);
		self.canvas_manip.synchronize(self.manip_registry);
	
	def paste_entities(self):
		pasted = self.clipboard.paste(self.scene["entities"]);
		offset = PASTE_OFFSET * self.clipboard.paste_count;

		if len(pasted) > 0:
			self.selection_context.clear();
		for entity in pasted:
			x, y = entity["position"];
			position = (x+offset, y+offset);
			if self.snap:
				position = self.canvas_grid.snap_point(position);
			entity["position"] = [int(position[0]), int(position[1])];
			self.selection_context.select(entity);

	def begin_rename(self, entity):
		self.rename_target = entity;
		self.rename_buffer = entity["name"];
		# Popup IDs hash against the ID stack, so the popup must be opened
		# from window level rather than from inside the context menu.
		self.rename_pending = True;

	def draw_rename_modal(self):
		modal_id = "Rename entity";
		if self.rename_pending:
			imgui.open_popup(modal_id);
			self.rename_pending = False;

		if self.rename_target == None:
			return;

		visible, _ = imgui.begin_popup_modal(modal_id, None, imgui.WindowFlags_.always_auto_resize);
		if not visible:
			self.rename_target = None;
			return;

		old_name = self.rename_target["name"];

		if imgui.is_window_appearing():
			imgui.set_keyboard_focus_here();
		imgui.set_next_item_width(256);
		submitted, self.rename_buffer = imgui.input_text(
			"##rename", self.rename_buffer, imgui.InputTextFlags_.enter_returns_true
		);

		new_name = self.rename_buffer.strip();
		collision = new_name != old_name and any(e["name"] == new_name for e in self.scene["entities"]);
		valid = len(new_name) > 0 and not collision;

		if collision:
			imgui.text_colored(imgui.ImVec4(1.0, 0.4, 0.4, 1.0), "Name already in use");
		elif len(new_name) == 0:
			imgui.text_colored(imgui.ImVec4(1.0, 0.4, 0.4, 1.0), "Name cannot be empty");

		imgui.begin_disabled(not valid);
		commit = imgui.button("Rename") or (submitted and valid);
		imgui.end_disabled();
		imgui.same_line();
		cancel = imgui.button("Cancel") or imgui.is_key_pressed(imgui.Key.escape);

		if commit:
			self.rename_target["name"] = new_name;
			self.rename_target = None;
			imgui.close_current_popup();
		elif cancel:
			self.rename_target = None;
			imgui.close_current_popup();

		imgui.end_popup();

	def draw_menu_bar(self):
		if imgui.begin_menu_bar():

			if imgui.begin_menu("Scene"):
				if imgui.begin_menu("Open"):
					scenes = AssetManager.get_all("scene");
					scene_last = self.scene;
					for scene in scenes:
						if imgui.menu_item_simple(scene["name"]):
							self.scene = scene;
					if self.scene != scene_last:
						self._load_scene(self.scene);
					imgui.end_menu();
				imgui.end_menu();
			
			if imgui.begin_menu("View"):
				self.scene_viewer.draw_menu();
				imgui.separator();
				if imgui.menu_item_simple(f"Reset zoom ({self.canvas.scale:.2f}x)"):
					self.canvas.set_zoom(1.0, pivot=(0, 0));
				imgui.end_menu();
			
			if imgui.begin_menu("Grid"):
				imgui.set_next_item_width(64);
				self.canvas_grid.size = input_int("Size", self.canvas_grid.size, style=EEGUIIntStyle.SLIDER, low_bound=2, high_bound=16);
				self.snap = input_bool("Snap", self.snap);
				imgui.end_menu();
			
			imgui.end_menu_bar();		
	
	def gui_draw_entities(self):
		_, self.entity_search = imgui.input_text("Search", self.entity_search);

		for entity in self.scene["entities"]:
			name = entity["name"] if len(entity["name"]) > 0 else str(id(entity));
			if len(self.entity_search) > 0 and self.entity_search not in name:
				continue;

			sprite = self.get_entity_sprite(entity);

			imgui.set_next_item_open(self.selection_context.is_selected(entity));
			node_open = imgui.tree_node(f"{name}####{id(entity)}");

			if imgui.begin_popup_context_item():
				if imgui.menu_item_simple("Rename"):
					self.begin_rename(entity);
					imgui.close_current_popup();
				if imgui.menu_item_simple("Delete"):
					self.trash.trash_item(self.scene["entities"], entity);
					imgui.close_current_popup();
				imgui.end_popup();
			
			if node_open:
				self.selection_context.select(entity, exclusive=True);
				
				entity["name"] = input_string("Name", entity["name"]);
				imgui.same_line();
				entity["enabled"] = input_bool("##enabled", entity["enabled"]);
				entity["prototype"] = input_asset("Prototype", entity["prototype"], "prototype");
				if len(entity["prototype"]) > 0 and len(entity["name"]) <= 0:
					entity["name"] = entity["prototype"];

				entity["frame_idx"] = input_int("Frame", entity["frame_idx"], EEGUIIntStyle.SLIDER, 0, sprite.frame_count-1);
				
				if imgui.tree_node("Script data"):
					for entry in entity["script_data"]:
						if not imgui.tree_node(entry["script"]):
							continue;
						for datum in entry["data"]:
							sd = scripts.ScriptDatum(datum["signature"]["key"], datum["signature"]["type"]);
							if imgui.tree_node(f"{sd.key}##{entry["script"]}"):
								datum["value"] = typed_input(f"##{sd.key}##{entry["script"]}", sd.type, datum["value"]);
								imgui.tree_pop();
						imgui.tree_pop();
					if imgui.button("Reset to defaults"):
						entity["script_data"] = [];
					imgui.tree_pop();
				imgui.tree_pop();
	
	def gui_draw_properties_editor(self):
		self.scene["has_background"] = input_bool("Has background", self.scene["has_background"]);
		if self.scene["has_background"]:
			self.scene["background"] = input_colour("Background", self.scene["background"]);
		self.scene["has_bounds"] = input_bool("Has bounds", self.scene["has_bounds"]);
		if self.scene["has_bounds"]:
			self.scene["bounds"] = input_aabb("Bounds", self.scene["bounds"]);
		self.scene["free_camera"] = input_bool("Free camera", self.scene["free_camera"]);
		self.scene["script"] = input_asset("Script", self.scene.get("script", ""), "script");

		# parallax lag is measured from this point, so decorations sit where
		# they were placed when the camera is over it
		self.scene["parallax_origin"] = input_vec2("Parallax origin", self.scene["parallax_origin"]);
		imgui.same_line();
		imgui.begin_disabled(not self.scene["has_bounds"]);
		if imgui.button("Center parallax"):
			x0, y0, x1, y1 = self.scene["bounds"];
			self.scene["parallax_origin"] = [(x0+x1)//2, (y0+y1)//2];
		imgui.end_disabled();

	def draw(self):
		self.draw_menu_bar();

		if not self._is_scene_loaded():
			return;

		self.canvas_io.tick();
		self.synchronize_manip();

		# An entity's script data only drifts from its prototype's when one of
		# them is edited (a spawn, a paste, a prototype change, a script edit in
		# the prototype editor), and every one of those leaves its document
		# dirty until the next history commit. _load_scene covers the rest.
		if AssetManager.get_document("scene").is_dirty() or AssetManager.get_document("prototype").is_dirty():
			for entity in self.scene["entities"]:
				rectify_entity_script_data(entity);

		def run_left_panel(panel_tick):
			imgui.begin_child(
				"left-panel",
				imgui.ImVec2((imgui.get_content_region_avail().x - self.canvas.view_size[0]) * 0.9, imgui.get_content_region_avail().y),
				0, 0
			);
			panel_tick();
			imgui.end_child();
		
		def entities_tick():
			if InputManager.is_command(glfw.KEY_C):
				self.clipboard.copy(self.selection_context.get_selection(single=True), copy_mode=Clipboard.CopyMode.DEEP, exclusive=True);
			if InputManager.is_command(glfw.KEY_V):
				self.paste_entities();
			
			if InputManager.is_command(glfw.KEY_A):
				self.spawn_popup.open();
			if InputManager.is_command(glfw.KEY_D):
				selection = self.selection_context.get_selection(single=True);
				if selection != None:
					self.trash.trash_item(self.scene["entities"], selection);
			
			self.spawn_popup.draw();
			self.draw_rename_modal();

			self.canvas_manip.tick();
			self.handle_events();

			self.gui_draw_entities();
			self.trash.flush();

		def tilemap_tick():
			self.tilemap_editor.tick();
			self.tilemap_editor.draw_gui();
		
		def walls_tick():
			self.wall_editor.tick();
			self.wall_editor.draw_gui();
		
		def doors_tick():
			self.pan_tick();
			self.door_editor.logic();
			self.door_editor.gui();
		
		def navlists_tick():
			self.navlist_editor.logic();
			self.navlist_editor.draw_gui();
		
		def decorations_tick():
			self.decoration_editor.tick();
			self.decoration_editor.draw_gui();
		
		def properties_tick():
			self.pan_tick();
			self.gui_draw_properties_editor();

		def foliage_tick():
			self.foliage_editor.tick();
			self.foliage_editor.draw_gui();
		
		match self.edit_mode:
			case EditMode.ENTITIES:
				run_left_panel(entities_tick);
			case EditMode.TILEMAP:
				run_left_panel(tilemap_tick);
			case EditMode.WALLS:
				run_left_panel(walls_tick);
			case EditMode.DOORS:
				run_left_panel(doors_tick);
			case EditMode.NAVLISTS:
				run_left_panel(navlists_tick);
			case EditMode.DECORATIONS:
				run_left_panel(decorations_tick);
			case EditMode.PROPERTIES:
				run_left_panel(properties_tick);	
			case EditMode.FOLIAGE:
				run_left_panel(foliage_tick);

		imgui.same_line();
		imgui.begin_child(
			"main-panel",
			imgui.ImVec2(imgui.get_content_region_avail().x, imgui.get_content_region_avail().y),
			0, imgui.WindowFlags_.no_scroll_with_mouse # the wheel zooms the canvas
		);

		if imgui.begin_tab_bar("edit-mode"):
			for value in EditMode:
				tab_visible, tab_open = imgui.begin_tab_item(value.name);
				if tab_visible:
					self.edit_mode = value;
					imgui.end_tab_item();
			imgui.end_tab_bar();

		# Zoom before drawing, so this frame is drawn at the new zoom. has_mouse
		# and the cursor are from last frame's render, which is close enough.
		wheel = imgui.get_io().mouse_wheel;
		if wheel != 0 and self.canvas.has_mouse:
			self.canvas.set_zoom(self.canvas.scale * (ZOOM_STEP ** wheel), pivot=self.canvas_io.get_cursor());

		self.scene_viewer.draw();
		self.canvas.render(gui_id="canvas");
		
		imgui.end_child();
